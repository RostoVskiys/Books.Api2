﻿using Book5.Data;

namespace Book5.Middleware
{
    public class BookExistsMiddleware
    {
        private readonly RequestDelegate next;

        public BookExistsMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var method = context.Request.Method;
            var path = context.Request.Path.Value ?? "";

            if (method == "GET" && path.StartsWith("/books/"))
            {
                var idStr = path.Split('/').Last();

                if (int.TryParse(idStr, out int id))
                {
                    var book = BookData.books.FirstOrDefault(x => x.Id == id);

                    if (book == null)
                    {
                        context.Response.StatusCode = 404;
                        await context.Response.WriteAsync("book not found");
                        return;
                    }

                    context.Items["book"] = book;
                }
            }

            await next(context);
        }
    }
}