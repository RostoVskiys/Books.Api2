﻿namespace Book5.Middleware
{
    public class AdminMiddleware
    {
        private readonly RequestDelegate next;

        public AdminMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var method = context.Request.Method;
            var path = context.Request.Path.Value?.ToLower() ?? "";

            if ((method == "POST" && path == "/books") ||
                (method == "DELETE" && path.StartsWith("/books/")))
            {
                var role = context.Request.Headers["x-user-role"].ToString().ToLower();

                if (role != "admin")
                {
                    context.Response.StatusCode = 403;
                    await context.Response.WriteAsJsonAsync(new { error = "access denied" });
                    return;
                }
            }

            await next(context);
        }
    }
}