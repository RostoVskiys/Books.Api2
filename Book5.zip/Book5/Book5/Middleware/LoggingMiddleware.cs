﻿using System.Globalization;

namespace Book5.Middleware
{
    public class LoggingMiddleware
    {
        private readonly RequestDelegate next;

        public LoggingMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var method = context.Request.Method;
            var url = context.Request.Path;
            var time = DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture);

            Console.WriteLine($"{method} {url} — {time}");

            await next(context);
        }
    }
}