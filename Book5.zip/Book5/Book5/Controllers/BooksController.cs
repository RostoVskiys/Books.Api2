﻿using Book5.Data;
using Book5.Models;
using Book5.Data;
using Book5.Models;
using Microsoft.AspNetCore.Mvc;

namespace BookStore5.Controllers
{
    [ApiController]
    public class BooksController : ControllerBase
    {
        [HttpGet("/books")]
        public IActionResult GetAll()
        {
            return Ok(BookData.books);
        }

        [HttpGet("/books/{id}")]
        public IActionResult GetById()
        {
            var book = HttpContext.Items["book"] as Book;
            return Ok(book);
        }

        [HttpPost("/books")]
        public IActionResult Create(Book book)
        {
            book.Id = BookData.books.Count == 0 ? 1 : BookData.books.Max(x => x.Id) + 1;

            BookData.books.Add(book);

            return Ok(book);
        }

        [HttpDelete("/books/{id}")]
        public IActionResult Delete(int id)
        {
            var book = BookData.books.FirstOrDefault(x => x.Id == id);

            if (book == null)
                return NotFound();

            BookData.books.Remove(book);

            return Ok();
        }
    }
}