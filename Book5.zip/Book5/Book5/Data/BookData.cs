﻿using Book5.Models;

namespace Book5.Data
{
    public static class BookData
    {
        public static List<Book> books = new List<Book>()
        {
            new Book { Id = 1, title = "clean code", author = "robert martin" },
            new Book { Id = 2, title = "clr via c#", author = "jeffrey richter" }
        };
    }
}