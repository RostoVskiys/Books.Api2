﻿using Microsoft.AspNetCore.Mvc;
using YourProjectName.Models;

namespace YourProjectName.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private static List<Order> zakazi = new List<Order>
        {
            new Order { Id = 1, Number = "A001", Total = 100.5m, CreatedAt = DateTime.Now },
            new Order { Id = 2, Number = "A002", Total = 250m, CreatedAt = DateTime.Now },
            new Order { Id = 3, Number = "A003", Total = 75.25m, CreatedAt = DateTime.Now }
        };

        // /api/orders
        [HttpGet]
        public IActionResult GetOrders()
        {
            return Ok(zakazi);
        }

        // /api/orders/{id}
        [HttpGet("{id:int}")]
        public IActionResult GetOrderById(int id)
        {
            var zakaz = zakazi.FirstOrDefault(x => x.Id == id);

            if (zakaz == null)
            {
                return NotFound("Order not found");
            }

            return Ok(zakaz);
        }

        // /api/orders
        [HttpPost]
        public IActionResult CreateOrder([FromBody] OrderDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.Number) || dto.Total <= 0)
            {
                return BadRequest("Number и Total обязательны");
            }

            var newId = zakazi.Max(x => x.Id) + 1;

            var newOrder = new Order
            {
                Id = newId,
                Number = dto.Number,
                Total = dto.Total,
                CreatedAt = DateTime.Now
            };

            zakazi.Add(newOrder);

            return CreatedAtAction(nameof(GetOrderById), new { id = newId }, newOrder);
        }

        // /api/orders/{id}
        [HttpPut("{id:int}")]
        public IActionResult UpdateOrder(int id, [FromBody] OrderDto dto)
        {
            var zakaz = zakazi.FirstOrDefault(x => x.Id == id);

            if (zakaz == null)
            {
                return NotFound("Order not found");
            }

            if (dto == null || string.IsNullOrWhiteSpace(dto.Number) || dto.Total <= 0)
            {
                return BadRequest("Number и Total обязательны");
            }

            zakaz.Number = dto.Number;
            zakaz.Total = dto.Total;

            return Ok(zakaz);
        }

        // /api/orders/{id}
        [HttpDelete("{id:int}")]
        public IActionResult DeleteOrder(int id)
        {
            var zakaz = zakazi.FirstOrDefault(x => x.Id == id);

            if (zakaz == null)
            {
                return NotFound("Order not found");
            }

            zakazi.Remove(zakaz);

            return NoContent();
        }

        // /api/orders/search
        [HttpGet("search")]
        public IActionResult Search(string number, decimal? minTotal)
        {
            if (string.IsNullOrWhiteSpace(number))
            {
                return BadRequest("number обязателен");
            }

            var result = zakazi.Where(x =>
                x.Number.ToLower().Contains(number.ToLower()) &&
                (!minTotal.HasValue || x.Total >= minTotal.Value)
            ).ToList();

            return Ok(result);
        }
    }
}