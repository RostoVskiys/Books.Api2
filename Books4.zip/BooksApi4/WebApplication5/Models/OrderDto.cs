﻿namespace YourProjectName.Models
{
    public class OrderDto
    {
        public string Number { get; set; }
        public decimal Total { get; set; }
    }
}